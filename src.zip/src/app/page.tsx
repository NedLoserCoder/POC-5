import Header from '@components/app/components/Header';

const HomePage = () => {
  return (
    <div>
      <Header title="Bom dia, Vietnã!" />
      <p>Não sei o que botar de subtítulo :P</p>
    </div>
  );
};

export default HomePage;
